﻿namespace DesktopFiksa
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            dataGridView1 = new DataGridView();
            button1 = new Button();
            textBoxnama = new TextBox();
            textBoxjenis = new TextBox();
            textBoxharga = new TextBox();
            Nama = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            btnUpdate = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.AntiqueWhite;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(309, 130);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(708, 309);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button1
            // 
            button1.BackColor = Color.LightCyan;
            button1.Location = new Point(134, 306);
            button1.Margin = new Padding(2);
            button1.Name = "button1";
            button1.Size = new Size(151, 34);
            button1.TabIndex = 1;
            button1.Text = "Tambahkan";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBoxnama
            // 
            textBoxnama.Location = new Point(134, 131);
            textBoxnama.Margin = new Padding(2);
            textBoxnama.Name = "textBoxnama";
            textBoxnama.Size = new Size(150, 31);
            textBoxnama.TabIndex = 2;
            // 
            // textBoxjenis
            // 
            textBoxjenis.Location = new Point(134, 188);
            textBoxjenis.Margin = new Padding(2);
            textBoxjenis.Name = "textBoxjenis";
            textBoxjenis.Size = new Size(150, 31);
            textBoxjenis.TabIndex = 3;
            textBoxjenis.TextChanged += textBoxjenis_TextChanged;
            // 
            // textBoxharga
            // 
            textBoxharga.Location = new Point(134, 249);
            textBoxharga.Margin = new Padding(2);
            textBoxharga.Name = "textBoxharga";
            textBoxharga.Size = new Size(150, 31);
            textBoxharga.TabIndex = 4;
            // 
            // Nama
            // 
            Nama.AutoSize = true;
            Nama.Location = new Point(12, 134);
            Nama.Margin = new Padding(2, 0, 2, 0);
            Nama.Name = "Nama";
            Nama.Size = new Size(59, 25);
            Nama.TabIndex = 5;
            Nama.Text = "Nama";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 188);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(49, 25);
            label1.TabIndex = 6;
            label1.Text = "Jenis";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 249);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(60, 25);
            label2.TabIndex = 7;
            label2.Text = "Harga";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(532, 21);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(256, 32);
            label3.TabIndex = 8;
            label3.Text = "Tambahkan Makanan";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1059, 131);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(312, 309);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.LightCyan;
            button2.Location = new Point(10, 304);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(118, 36);
            button2.TabIndex = 11;
            button2.Text = "Next";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(16, 367);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(112, 34);
            btnUpdate.TabIndex = 12;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Teal;
            ClientSize = new Size(1459, 630);
            Controls.Add(btnUpdate);
            Controls.Add(button2);
            Controls.Add(pictureBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Nama);
            Controls.Add(textBoxharga);
            Controls.Add(textBoxjenis);
            Controls.Add(textBoxnama);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button button1;
        private TextBox textBoxnama;
        private TextBox textBoxjenis;
        private TextBox textBoxharga;
        private Label Nama;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox1;
        private Button button2;
        private Button btnUpdate;
    }
}