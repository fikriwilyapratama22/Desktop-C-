﻿using System;
using System.Data;
using System.Windows.Forms;

namespace DesktopFiksa
{
    public partial class Form2 : Form
    {
        private koneksidatabase databaseconnection;

        public Form2()
        {
            InitializeComponent();
            databaseconnection = new koneksidatabase();

            // Isi ComboBox Makanan dan Minuman
            FillComboBox("SELECT id, nama FROM makanan", comboBoxMakanan, "id", "nama");
            FillComboBox("SELECT id, nama FROM minuman", comboBoxMinuman, "id", "nama");
        }

        private void FillComboBox(string query, ComboBox comboBox, string valueMember, string displayMember)
        {
            try
            {
                // Ambil data dari database dan isi ComboBox
                var dataTable = databaseconnection.GetDataTable(query);

                // Set properti ValueMember dan DisplayMember
                comboBox.ValueMember = valueMember;
                comboBox.DisplayMember = displayMember;

                // Set DataSource ComboBox dengan data dari database
                comboBox.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private int GetHargaFromDatabase(string tableName, int id)
        {
            try
            {
                // Ambil harga dari database berdasarkan id
                string query = $"SELECT harga FROM {tableName} WHERE id = {id}";
                var harga = databaseconnection.GetDataTable(query).Rows[0]["harga"];
                return int.Parse(harga.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error getting harga from database: {ex.Message}");
                return 0;
            }
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {
            try
            {
                // Ambil id dan nama makanan dari ComboBox
                int idMakanan = int.Parse(comboBoxMakanan.SelectedValue.ToString());
                string namaMakanan = comboBoxMakanan.Text;

                // Ambil id dan nama minuman dari ComboBox
                int idMinuman = int.Parse(comboBoxMinuman.SelectedValue.ToString());
                string namaMinuman = comboBoxMinuman.Text;

                // Ambil porsi makanan dan minuman dari TextBox
                int porsiMakanan = int.Parse(textBoxPorsiMakanan.Text);
                int porsiMinuman = int.Parse(textBoxPorsiMinuman.Text);

                // Ambil harga makanan dan minuman dari database
                int hargaMakanan = GetHargaFromDatabase("makanan", idMakanan);
                int hargaMinuman = GetHargaFromDatabase("minuman", idMinuman);

                // Tampilkan harga makanan dan minuman di TextBox
                textBoxHargaMakanan.Text = hargaMakanan.ToString();
                textBoxHargaMinuman.Text = hargaMinuman.ToString();

                // Hitung total makanan dan minuman
                int totalMakanan = porsiMakanan * hargaMakanan;
                int totalMinuman = porsiMinuman * hargaMinuman;

                // Hitung total bayar keseluruhan
                int totalBayar = totalMakanan + totalMinuman;

                // Tampilkan total bayar di TextBox
                textBoxTotalHarga.Text = totalBayar.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error calculating total bayar: " + ex.Message);
            }
        }



        private void btnbayar_Click(object sender, EventArgs e)
        {
            try
            {
                // Ambil total bayar dan uang bayar dari TextBox
                int totalBayar = int.Parse(textBoxTotalHarga.Text);
                int uangBayar = int.Parse(txtbayar.Text);

                // Hitung kembalian
                int kembalian = uangBayar - totalBayar;

                // Tampilkan kembalian di TextBox
                txtkembali.Text = kembalian.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error processing payment: " + ex.Message);
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void comboBoxMinuman_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                // Reset semua nilai dan teks ke nilai awal atau kosong
                comboBoxMakanan.SelectedIndex = -1;
                comboBoxMinuman.SelectedIndex = -1;
                textBoxPorsiMakanan.Clear();
                textBoxPorsiMinuman.Clear();
                textBoxHargaMakanan.Clear();
                textBoxHargaMinuman.Clear();
                textBoxTotalHarga.Clear();
                txtbayar.Clear();
                txtkembali.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error resetting values: " + ex.Message);
            }
        }

        private void btnKeluar_Click(object sender, EventArgs e)
        {
            try
            {
                // Menutup formulir saat tombol keluar ditekan
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error closing the form: " + ex.Message);
            }
        }
    }
}
