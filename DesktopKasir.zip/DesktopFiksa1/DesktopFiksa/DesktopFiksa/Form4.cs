﻿using System;
using System.Windows.Forms;

namespace DesktopFiksa
{
    public partial class Form4 : Form
    {
        private koneksidatabase dbConnection;

        public Form4()
        {
            InitializeComponent();
            dbConnection = new koneksidatabase();
            LoadDataToGridView();
        }

        private void buttonsimpan_Click(object sender, EventArgs e)
        {
            // Pastikan TextBox tidak kosong sebelum menambahkan ke database
            if (!string.IsNullOrEmpty(textBoxnama.Text) && !string.IsNullOrEmpty(textBoxharga.Text))
            {
                string query = $"INSERT INTO minuman (nama, harga) VALUES ('{textBoxnama.Text}', '{textBoxharga.Text}')";

                // Simpan data ke database
                dbConnection.SaveData(query);

                // Bersihkan TextBox setelah ditambahkan
                textBoxnama.Clear();
                textBoxharga.Clear();

                // Tampilkan data terbaru di DataGridView
                LoadDataToGridView();
            }
            else
            {
                MessageBox.Show("Nama dan Harga tidak boleh kosong!");
            }
        }

        private void LoadDataToGridView()
        {
            try
            {
                // Ambil data dari database dan tampilkan di DataGridView
                string selectQuery = "SELECT nama, harga FROM minuman";
                dataGridView1.DataSource = dbConnection.GetDataTable(selectQuery);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Pastikan ada baris yang dipilih di DataGridView
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Ambil nilai nama dan harga dari TextBox
                    string namaBaru = textBoxnama.Text;
                    string hargaBaru = textBoxharga.Text;

                    // Ambil nilai nama dan harga yang dipilih di DataGridView
                    string namaLama = dataGridView1.SelectedRows[0].Cells["nama"].Value.ToString();
                    string hargaLama = dataGridView1.SelectedRows[0].Cells["harga"].Value.ToString();

                    // Pastikan nilai baru tidak kosong
                    if (!string.IsNullOrEmpty(namaBaru) && !string.IsNullOrEmpty(hargaBaru))
                    {
                        // Bangun query UPDATE
                        string updateQuery = $"UPDATE minuman SET nama = '{namaBaru}', harga = '{hargaBaru}' WHERE nama = '{namaLama}' AND harga = '{hargaLama}'";

                        // Jalankan query untuk update
                        dbConnection.SaveData(updateQuery);

                        // Bersihkan TextBox setelah diupdate
                        textBoxnama.Clear();
                        textBoxharga.Clear();

                        // Tampilkan data terbaru di DataGridView
                        LoadDataToGridView();
                    }
                    else
                    {
                        MessageBox.Show("Nama dan Harga tidak boleh kosong!");
                    }
                }
                else
                {
                    MessageBox.Show("Pilih baris yang akan diupdate.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating data: {ex.Message}");
            }
        }
    }
}
