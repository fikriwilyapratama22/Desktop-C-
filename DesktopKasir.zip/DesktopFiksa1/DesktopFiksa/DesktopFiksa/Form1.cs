using System;
using System.Data;
using System.Windows.Forms;

namespace DesktopFiksa
{
    public partial class Form1 : Form
    {
        private koneksidatabase databaseconnection;
        private DataTable dataTable;

        public Form1()
        {
            InitializeComponent();
            databaseconnection = new koneksidatabase();

            if (!databaseconnection.Connect())
            {
                MessageBox.Show("Gagal terhubung ke database. Aplikasi akan ditutup.");
                this.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string query = "SELECT ID, nama, jenis, harga FROM makanan";
            dataTable = databaseconnection.GetDataTable(query);

            // Sembunyikan kolom "ID"
            if (dataGridView1.Columns.Contains("ID"))
            {
                dataGridView1.Columns["ID"].Visible = false;
            }

            dataGridView1.DataSource = dataTable;
            dataGridView1.Columns["ID"].Visible = false; // Tambahkan baris ini untuk menyembunyikan kolom "ID"
        }



        private void button1_Click(object sender, EventArgs e)
        {

            try
            {

                string namaBaru = textBoxnama.Text;
                string jenisBaru = textBoxjenis.Text;
                double hargaBaru = Convert.ToDouble(textBoxharga.Text);

                DataRow newRow = dataTable.NewRow();
                newRow["nama"] = namaBaru;
                newRow["jenis"] = jenisBaru;
                newRow["harga"] = hargaBaru;

                dataTable.Rows.Add(newRow);

                dataGridView1.Refresh();


                string saveQuery = $"INSERT INTO makanan (nama, jenis, harga) VALUES ('{namaBaru}', '{jenisBaru}', {hargaBaru})";
                databaseconnection.SaveData(saveQuery);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void textBoxjenis_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Pastikan ada baris yang dipilih di DataGridView
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Ambil baris yang dipilih
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Ambil nilai dari kolom "ID"
                    int idToUpdate = Convert.ToInt32(selectedRow.Cells["ID"].Value);

                    // Ambil nilai yang akan diupdate dari TextBox
                    string namaBaru = textBoxnama.Text;
                    string jenisBaru = textBoxjenis.Text;
                    double hargaBaru = Convert.ToDouble(textBoxharga.Text);

                    // Update nilai pada DataTable
                    DataRow[] rowsToUpdate = dataTable.Select($"ID = {idToUpdate}");
                    if (rowsToUpdate.Length > 0)
                    {
                        rowsToUpdate[0]["nama"] = namaBaru;
                        rowsToUpdate[0]["jenis"] = jenisBaru;
                        rowsToUpdate[0]["harga"] = hargaBaru;

                        // Refresh DataGridView
                        dataGridView1.Refresh();

                        // Update nilai di database
                        string updateQuery = $"UPDATE makanan SET nama = '{namaBaru}', jenis = '{jenisBaru}', harga = {hargaBaru} WHERE ID = {idToUpdate}";
                        databaseconnection.SaveData(updateQuery);
                    }
                    else
                    {
                        MessageBox.Show("Data tidak ditemukan.");
                    }
                }
                else
                {
                    MessageBox.Show("Pilih baris yang akan diupdate.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating data: {ex.Message}");
            }
        }
    }
}
