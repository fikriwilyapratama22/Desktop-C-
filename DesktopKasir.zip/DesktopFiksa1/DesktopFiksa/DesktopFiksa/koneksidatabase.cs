﻿using MySql.Data.MySqlClient;
using System;
using System.Data;

namespace DesktopFiksa
{
    internal class koneksidatabase
    {
        public MySqlConnection conn { get; private set; }
        private string host = "localhost";
        private string user = "root";
        private string password = "";
        private string database = "db_makanan";

        public koneksidatabase()
        {
            Connect();
        }

        public bool Connect()
        {
            string connStr = $"server={host};user={user};database={database};password={password};";
            conn = new MySqlConnection(connStr);

            try
            {
                conn.Open();
                Console.WriteLine("Koneksi sukses!");
                return true;
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return false;
            }
        }

        public void CloseConnection()
        {
            if (conn != null && conn.State == ConnectionState.Open)
            {
                conn.Close();
                Console.WriteLine("Koneksi ditutup.");
            }
        }

        public DataTable GetDataTable(string query)
        {
            DataTable dataTable = new DataTable();

            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        dataTable.Load(reader);
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return dataTable;
        }

        public void SaveData(string query)
        {
            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
    }
}
