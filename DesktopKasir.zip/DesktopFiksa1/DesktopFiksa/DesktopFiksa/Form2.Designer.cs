﻿namespace DesktopFiksa
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            textBoxPorsiMinuman = new TextBox();
            groupBox1 = new GroupBox();
            textBoxHargaMinuman = new TextBox();
            comboBoxMinuman = new ComboBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            textBoxHargaMakanan = new TextBox();
            comboBoxMakanan = new ComboBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            textBoxPorsiMakanan = new TextBox();
            label26 = new Label();
            label27 = new Label();
            label28 = new Label();
            textBoxTotalHarga = new TextBox();
            txtbayar = new TextBox();
            txtkembali = new TextBox();
            btnTotal = new Button();
            btnReset = new Button();
            btnKeluar = new Button();
            btnbayar = new Button();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBoxPorsiMinuman
            // 
            textBoxPorsiMinuman.Location = new Point(16, 140);
            textBoxPorsiMinuman.Margin = new Padding(2);
            textBoxPorsiMinuman.Name = "textBoxPorsiMinuman";
            textBoxPorsiMinuman.Size = new Size(343, 31);
            textBoxPorsiMinuman.TabIndex = 5;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.PaleTurquoise;
            groupBox1.Controls.Add(textBoxHargaMinuman);
            groupBox1.Controls.Add(comboBoxMinuman);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBoxPorsiMinuman);
            groupBox1.Location = new Point(48, 89);
            groupBox1.Margin = new Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2);
            groupBox1.Size = new Size(458, 275);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Minuman";
            // 
            // textBoxHargaMinuman
            // 
            textBoxHargaMinuman.Location = new Point(16, 216);
            textBoxHargaMinuman.Margin = new Padding(4);
            textBoxHargaMinuman.Name = "textBoxHargaMinuman";
            textBoxHargaMinuman.Size = new Size(343, 31);
            textBoxHargaMinuman.TabIndex = 27;
            // 
            // comboBoxMinuman
            // 
            comboBoxMinuman.FormattingEnabled = true;
            comboBoxMinuman.Location = new Point(16, 60);
            comboBoxMinuman.Margin = new Padding(4);
            comboBoxMinuman.Name = "comboBoxMinuman";
            comboBoxMinuman.Size = new Size(343, 33);
            comboBoxMinuman.TabIndex = 26;
            comboBoxMinuman.SelectedIndexChanged += comboBoxMinuman_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 181);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(142, 25);
            label4.TabIndex = 10;
            label4.Text = "Harga/Minuman";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 110);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(50, 25);
            label3.TabIndex = 9;
            label3.Text = "Porsi";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 30);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(76, 25);
            label2.TabIndex = 8;
            label2.Text = "Pesanan";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(432, 23);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(324, 32);
            label1.TabIndex = 0;
            label1.Text = "PESANAN PELANGGAN";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.PaleTurquoise;
            groupBox2.Controls.Add(textBoxHargaMakanan);
            groupBox2.Controls.Add(comboBoxMakanan);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(textBoxPorsiMakanan);
            groupBox2.Location = new Point(42, 421);
            groupBox2.Margin = new Padding(2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(2);
            groupBox2.Size = new Size(458, 279);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "Makanan";
            // 
            // textBoxHargaMakanan
            // 
            textBoxHargaMakanan.Location = new Point(21, 228);
            textBoxHargaMakanan.Margin = new Padding(4);
            textBoxHargaMakanan.Name = "textBoxHargaMakanan";
            textBoxHargaMakanan.Size = new Size(343, 31);
            textBoxHargaMakanan.TabIndex = 15;
            // 
            // comboBoxMakanan
            // 
            comboBoxMakanan.FormattingEnabled = true;
            comboBoxMakanan.Location = new Point(21, 61);
            comboBoxMakanan.Margin = new Padding(4);
            comboBoxMakanan.Name = "comboBoxMakanan";
            comboBoxMakanan.Size = new Size(343, 33);
            comboBoxMakanan.TabIndex = 14;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(21, 196);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(139, 25);
            label7.TabIndex = 10;
            label7.Text = "Harga/Makanan";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(21, 108);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(50, 25);
            label8.TabIndex = 9;
            label8.Text = "Porsi";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(21, 32);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(76, 25);
            label9.TabIndex = 8;
            label9.Text = "Pesanan";
            // 
            // textBoxPorsiMakanan
            // 
            textBoxPorsiMakanan.Location = new Point(21, 135);
            textBoxPorsiMakanan.Margin = new Padding(2);
            textBoxPorsiMakanan.Name = "textBoxPorsiMakanan";
            textBoxPorsiMakanan.Size = new Size(343, 31);
            textBoxPorsiMakanan.TabIndex = 5;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label26.Location = new Point(702, 466);
            label26.Margin = new Padding(2, 0, 2, 0);
            label26.Name = "label26";
            label26.Size = new Size(66, 28);
            label26.TabIndex = 16;
            label26.Text = "TOTAL";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label27.Location = new Point(702, 522);
            label27.Margin = new Padding(2, 0, 2, 0);
            label27.Name = "label27";
            label27.Size = new Size(69, 28);
            label27.TabIndex = 17;
            label27.Text = "BAYAR";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label28.Location = new Point(702, 585);
            label28.Margin = new Padding(2, 0, 2, 0);
            label28.Name = "label28";
            label28.Size = new Size(90, 28);
            label28.TabIndex = 18;
            label28.Text = "KEMBALI";
            // 
            // textBoxTotalHarga
            // 
            textBoxTotalHarga.Location = new Point(809, 466);
            textBoxTotalHarga.Margin = new Padding(2);
            textBoxTotalHarga.Name = "textBoxTotalHarga";
            textBoxTotalHarga.Size = new Size(198, 31);
            textBoxTotalHarga.TabIndex = 19;
            // 
            // txtbayar
            // 
            txtbayar.Location = new Point(809, 522);
            txtbayar.Margin = new Padding(2);
            txtbayar.Name = "txtbayar";
            txtbayar.Size = new Size(198, 31);
            txtbayar.TabIndex = 20;
            // 
            // txtkembali
            // 
            txtkembali.Location = new Point(809, 582);
            txtkembali.Margin = new Padding(2);
            txtkembali.Name = "txtkembali";
            txtkembali.Size = new Size(198, 31);
            txtkembali.TabIndex = 21;
            // 
            // btnTotal
            // 
            btnTotal.BackColor = Color.LightCyan;
            btnTotal.ForeColor = Color.Black;
            btnTotal.Location = new Point(1052, 454);
            btnTotal.Margin = new Padding(2);
            btnTotal.Name = "btnTotal";
            btnTotal.Size = new Size(112, 72);
            btnTotal.TabIndex = 22;
            btnTotal.Text = "Total";
            btnTotal.UseVisualStyleBackColor = false;
            btnTotal.Click += btnTotal_Click;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(710, 658);
            btnReset.Margin = new Padding(2);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(126, 32);
            btnReset.TabIndex = 24;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnKeluar
            // 
            btnKeluar.Location = new Point(895, 658);
            btnKeluar.Margin = new Padding(2);
            btnKeluar.Name = "btnKeluar";
            btnKeluar.Size = new Size(112, 32);
            btnKeluar.TabIndex = 25;
            btnKeluar.Text = "Keluar";
            btnKeluar.UseVisualStyleBackColor = true;
            btnKeluar.Click += btnKeluar_Click;
            // 
            // btnbayar
            // 
            btnbayar.BackColor = Color.LightCyan;
            btnbayar.Location = new Point(1052, 552);
            btnbayar.Margin = new Padding(2);
            btnbayar.Name = "btnbayar";
            btnbayar.Size = new Size(112, 72);
            btnbayar.TabIndex = 23;
            btnbayar.Text = "Bayar";
            btnbayar.UseVisualStyleBackColor = false;
            btnbayar.Click += btnbayar_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.AntiqueWhite;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(719, 89);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(399, 295);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 26;
            pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Teal;
            ClientSize = new Size(1240, 749);
            Controls.Add(pictureBox1);
            Controls.Add(btnKeluar);
            Controls.Add(btnReset);
            Controls.Add(btnbayar);
            Controls.Add(btnTotal);
            Controls.Add(txtkembali);
            Controls.Add(groupBox2);
            Controls.Add(txtbayar);
            Controls.Add(textBoxTotalHarga);
            Controls.Add(label28);
            Controls.Add(label27);
            Controls.Add(label26);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Margin = new Padding(2);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBoxPorsiMinuman;
        private GroupBox groupBox1;
        private Label label1;
        private Label label4;
        private Label label3;
        private Label label2;
        private GroupBox groupBox2;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox textBoxPorsiMakanan;
        private Label label26;
        private Label label27;
        private Label label28;
        private TextBox textBoxTotalHarga;
        private TextBox txtbayar;
        private TextBox txtkembali;
        private Button btnTotal;
        private Button btnReset;
        private Button btnKeluar;
        private ComboBox comboBoxMinuman;
        private ComboBox comboBoxMakanan;
        private Button btnbayar;
        private TextBox textBoxHargaMinuman;
        private TextBox textBoxHargaMakanan;
        private PictureBox pictureBox1;
    }
}