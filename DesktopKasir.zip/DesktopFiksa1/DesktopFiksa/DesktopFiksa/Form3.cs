﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopFiksa
{
    public partial class Form3 : Form
    {

        private const string EmailBenar = "Kelompok3@gmail.com";
        private const string PasswordBenar = "12345";

        public Form3()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputEmail = textBox1.Text;
            string inputPassword = textBox2.Text;

            if (inputEmail == EmailBenar && inputPassword == PasswordBenar)
            {
                Form1 form1 = new Form1();
                form1.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Email atau Password salah! silahkan coba lagi");

            }

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}